export function handleRedlineCommand(args) {
  if (args.length < 6) {
    return new Promise((resolve) => {
      resolve([
        [
          "Error - Too Few Arguments, Add a <minLong>, <maxLong>, <minLat>, and <maxLat> for successful retrieval"
        ]
      ]);
    });
  } else {
    const [minLong, maxLong, minLat, maxLat, ...rest] = args;
    if (rest.length !== 0) {
      return new Promise((resolve) => {
        resolve([["Error - Do Not Enter Args Other Than State and County"]]);
      });
    } else {
      const OR = fetch(
        `http://localhost:8080/redline?minLong=${minLong}&maxLong=${maxLong}&minLat=${minLat}&maxLat=${maxLat}`
      ).then((response) => response.json()).then((json) => {
        console.log(json);
        const redlined = [
          ["redlined regions", "information"],
          [json["redlined regions"], json.information]
        ];
        console.log(redlined);
        console.log(typeof redlined);
        if (typeof redlined[1][0] === "undefined") {
          const result = [[json.result + ": " + json.message]];
          return result;
        }
        return redlined;
      }).catch((e) => {
        console.log(e);
        return [["Error with data fetching for redline request"]];
      });
      return OR;
    }
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlZGxpbmVDb21tYW5kLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBmdW5jdGlvbiBoYW5kbGVSZWRsaW5lQ29tbWFuZChcbiAgYXJnczogQXJyYXk8c3RyaW5nPlxuKTogUHJvbWlzZTxzdHJpbmdbXVtdPiB7XG4gIGlmIChhcmdzLmxlbmd0aCA8IDYpIHtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICAgIHJlc29sdmUoW1xuICAgICAgICBbXG4gICAgICAgICAgXCJFcnJvciAtIFRvbyBGZXcgQXJndW1lbnRzLCBBZGQgYSA8bWluTG9uZz4sIDxtYXhMb25nPiwgPG1pbkxhdD4sIGFuZCA8bWF4TGF0PiBmb3Igc3VjY2Vzc2Z1bCByZXRyaWV2YWxcIixcbiAgICAgICAgXSxcbiAgICAgIF0pO1xuICAgIH0pO1xuICB9IGVsc2Uge1xuICAgIGNvbnN0IFttaW5Mb25nLCBtYXhMb25nLCBtaW5MYXQsIG1heExhdCwgLi4ucmVzdF0gPSBhcmdzO1xuICAgIGlmIChyZXN0Lmxlbmd0aCAhPT0gMCkge1xuICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICAgIHJlc29sdmUoW1tcIkVycm9yIC0gRG8gTm90IEVudGVyIEFyZ3MgT3RoZXIgVGhhbiBTdGF0ZSBhbmQgQ291bnR5XCJdXSk7XG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgT1IgPSBmZXRjaChcbiAgICAgICAgYGh0dHA6Ly9sb2NhbGhvc3Q6ODA4MC9yZWRsaW5lP21pbkxvbmc9JHttaW5Mb25nfSZtYXhMb25nPSR7bWF4TG9uZ30mbWluTGF0PSR7bWluTGF0fSZtYXhMYXQ9JHttYXhMYXR9YFxuICAgICAgKVxuICAgICAgICAudGhlbigocmVzcG9uc2UpID0+IHJlc3BvbnNlLmpzb24oKSlcbiAgICAgICAgLnRoZW4oKGpzb24pID0+IHtcbiAgICAgICAgICBjb25zb2xlLmxvZyhqc29uKTtcbiAgICAgICAgICBjb25zdCByZWRsaW5lZDogc3RyaW5nW11bXSA9IFtcbiAgICAgICAgICAgIFtcInJlZGxpbmVkIHJlZ2lvbnNcIiwgXCJpbmZvcm1hdGlvblwiXSxcbiAgICAgICAgICAgIFtqc29uW1wicmVkbGluZWQgcmVnaW9uc1wiXSwganNvbi5pbmZvcm1hdGlvbixdXG4gICAgICAgICAgXTtcbiAgICAgICAgICBjb25zb2xlLmxvZyhyZWRsaW5lZCk7XG4gICAgICAgICAgY29uc29sZS5sb2codHlwZW9mIHJlZGxpbmVkKTtcbiAgICAgICAgICBpZiAodHlwZW9mIHJlZGxpbmVkWzFdWzBdID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgICAgICBjb25zdCByZXN1bHQ6IHN0cmluZ1tdW10gPSBbW2pzb24ucmVzdWx0ICsgXCI6IFwiICsganNvbi5tZXNzYWdlXV07XG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gcmVkbGluZWQ7XG4gICAgICAgIH0pXG4gICAgICAgIC5jYXRjaCgoZSkgPT4ge1xuICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgIHJldHVybiBbW1wiRXJyb3Igd2l0aCBkYXRhIGZldGNoaW5nIGZvciByZWRsaW5lIHJlcXVlc3RcIl1dO1xuICAgICAgICB9KTtcbiAgICAgIHJldHVybiBPUjtcbiAgICB9XG4gIH1cbn1cbiJdLCJtYXBwaW5ncyI6IkFBQU8sZ0JBQVMscUJBQ2QsTUFDcUI7QUFDckIsTUFBSSxLQUFLLFNBQVMsR0FBRztBQUNuQixXQUFPLElBQUksUUFBUSxDQUFDLFlBQVk7QUFDOUIsY0FBUTtBQUFBLFFBQ047QUFBQSxVQUNFO0FBQUEsUUFDRjtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUFBLEVBQ0gsT0FBTztBQUNMLFVBQU0sQ0FBQyxTQUFTLFNBQVMsUUFBUSxRQUFRLEdBQUcsSUFBSSxJQUFJO0FBQ3BELFFBQUksS0FBSyxXQUFXLEdBQUc7QUFDckIsYUFBTyxJQUFJLFFBQVEsQ0FBQyxZQUFZO0FBQzlCLGdCQUFRLENBQUMsQ0FBQyx1REFBdUQsQ0FBQyxDQUFDO0FBQUEsTUFDckUsQ0FBQztBQUFBLElBQ0gsT0FBTztBQUNMLFlBQU0sS0FBSztBQUFBLFFBQ1QseUNBQXlDLE9BQU8sWUFBWSxPQUFPLFdBQVcsTUFBTSxXQUFXLE1BQU07QUFBQSxNQUN2RyxFQUNHLEtBQUssQ0FBQyxhQUFhLFNBQVMsS0FBSyxDQUFDLEVBQ2xDLEtBQUssQ0FBQyxTQUFTO0FBQ2QsZ0JBQVEsSUFBSSxJQUFJO0FBQ2hCLGNBQU0sV0FBdUI7QUFBQSxVQUMzQixDQUFDLG9CQUFvQixhQUFhO0FBQUEsVUFDbEMsQ0FBQyxLQUFLLGtCQUFrQixHQUFHLEtBQUssV0FBWTtBQUFBLFFBQzlDO0FBQ0EsZ0JBQVEsSUFBSSxRQUFRO0FBQ3BCLGdCQUFRLElBQUksT0FBTyxRQUFRO0FBQzNCLFlBQUksT0FBTyxTQUFTLENBQUMsRUFBRSxDQUFDLE1BQU0sYUFBYTtBQUN6QyxnQkFBTSxTQUFxQixDQUFDLENBQUMsS0FBSyxTQUFTLE9BQU8sS0FBSyxPQUFPLENBQUM7QUFDL0QsaUJBQU87QUFBQSxRQUNUO0FBQ0EsZUFBTztBQUFBLE1BQ1QsQ0FBQyxFQUNBLE1BQU0sQ0FBQyxNQUFNO0FBQ1osZ0JBQVEsSUFBSSxDQUFDO0FBQ2IsZUFBTyxDQUFDLENBQUMsOENBQThDLENBQUM7QUFBQSxNQUMxRCxDQUFDO0FBQ0gsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBQ0Y7IiwibmFtZXMiOltdfQ==