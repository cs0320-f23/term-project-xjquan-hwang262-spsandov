export function handleSearchCommand(args) {
  if (args.length < 2) {
    return new Promise((resolve) => {
      resolve([[
        "Error - Too Few Arguments, Add a <column> and <value> to search"
      ]]);
    });
  } else {
    const [column, value, ...rest] = args;
    if (rest.length !== 0) {
      return new Promise((resolve) => {
        resolve([[
          "Error - Do Not Enter Args Other Than Column and Value"
        ]]);
      });
    } else {
      const OR = fetch(`http://localhost:8080/searchcsv?target=${value}&identifier=${column}`).then((response) => response.json()).then((json) => {
        const data = json.data;
        if (typeof data === "undefined") {
          const result = [[json.result + ": " + json.message]];
          return result;
        }
        return data;
      }).catch((e) => {
        console.log(e);
        return [["Error with data fetching for search request"]];
      });
      return OR;
    }
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlYXJjaENvbW1hbmQudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUkVQTElucHV0UHJvcHMgfSBmcm9tIFwiLi4vY29tcG9uZW50cy9SRVBMSW5wdXRcIjtcblxuLy8gSGFuZGxlIHRoZSAnc2VhcmNoJyBjb21tYW5kIGFuZCBwZXJmb3JtIGEgc2VhcmNoIG9uIHRoZSBsb2FkZWQgQ1NWIGRhdGFcbmV4cG9ydCBmdW5jdGlvbiBoYW5kbGVTZWFyY2hDb21tYW5kKGFyZ3M6IEFycmF5PHN0cmluZz4pOiBQcm9taXNlPHN0cmluZ1tdW10+IHtcbiAgICBpZiAoYXJncy5sZW5ndGggPCAyKSB7XG4gICAgICByZXR1cm4gbmV3IFByb21pc2UocmVzb2x2ZSA9PiB7IFxuICAgICAgICByZXNvbHZlKFtbXG4gICAgICAgICAgXCJFcnJvciAtIFRvbyBGZXcgQXJndW1lbnRzLCBBZGQgYSA8Y29sdW1uPiBhbmQgPHZhbHVlPiB0byBzZWFyY2hcIixcbiAgICAgICAgXV0pO1xuICAgICAgfSlcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgW2NvbHVtbiwgdmFsdWUsIC4uLnJlc3RdID0gYXJncztcbiAgICAgIGlmIChyZXN0Lmxlbmd0aCAhPT0gMCkge1xuICAgICAgICByZXR1cm4gbmV3IFByb21pc2UocmVzb2x2ZSA9PiB7IFxuICAgICAgICAgIHJlc29sdmUoW1tcbiAgICAgICAgICAgIFwiRXJyb3IgLSBEbyBOb3QgRW50ZXIgQXJncyBPdGhlciBUaGFuIENvbHVtbiBhbmQgVmFsdWVcIixcbiAgICAgICAgICBdXSk7XG4gICAgICAgIH0pXG4gICAgICB9IGVsc2Uge1xuICAgICAgIGNvbnN0IE9SID0gZmV0Y2goYGh0dHA6Ly9sb2NhbGhvc3Q6ODA4MC9zZWFyY2hjc3Y/dGFyZ2V0PSR7dmFsdWV9JmlkZW50aWZpZXI9JHtjb2x1bW59YClcbiAgICAgICAudGhlbihyZXNwb25zZSA9PiByZXNwb25zZS5qc29uKCkpXG4gICAgICAgLnRoZW4oanNvbiA9PiB7XG4gICAgICAgIGNvbnN0IGRhdGE6IHN0cmluZ1tdW10gPSBqc29uLmRhdGFcbiAgICAgICAgaWYgKHR5cGVvZiBkYXRhID09PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgIGNvbnN0IHJlc3VsdCA6IHN0cmluZ1tdW10gPSBbW2pzb24ucmVzdWx0ICsgXCI6IFwiICsganNvbi5tZXNzYWdlXV1cbiAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBkYXRhO1xuICAgICAgIH0pXG4gICAgICAgLmNhdGNoKGUgPT4ge1xuICAgICAgICBjb25zb2xlLmxvZyhlKVxuICAgICAgICByZXR1cm4gW1tcIkVycm9yIHdpdGggZGF0YSBmZXRjaGluZyBmb3Igc2VhcmNoIHJlcXVlc3RcIl1dXG4gICAgICAgfSlcbiAgICAgICByZXR1cm4gT1I7XG4gICAgICB9XG4gICAgfVxuICB9Il0sIm1hcHBpbmdzIjoiQUFHTyxnQkFBUyxvQkFBb0IsTUFBMEM7QUFDMUUsTUFBSSxLQUFLLFNBQVMsR0FBRztBQUNuQixXQUFPLElBQUksUUFBUSxhQUFXO0FBQzVCLGNBQVEsQ0FBQztBQUFBLFFBQ1A7QUFBQSxNQUNGLENBQUMsQ0FBQztBQUFBLElBQ0osQ0FBQztBQUFBLEVBQ0gsT0FBTztBQUNMLFVBQU0sQ0FBQyxRQUFRLE9BQU8sR0FBRyxJQUFJLElBQUk7QUFDakMsUUFBSSxLQUFLLFdBQVcsR0FBRztBQUNyQixhQUFPLElBQUksUUFBUSxhQUFXO0FBQzVCLGdCQUFRLENBQUM7QUFBQSxVQUNQO0FBQUEsUUFDRixDQUFDLENBQUM7QUFBQSxNQUNKLENBQUM7QUFBQSxJQUNILE9BQU87QUFDTixZQUFNLEtBQUssTUFBTSwwQ0FBMEMsS0FBSyxlQUFlLE1BQU0sRUFBRSxFQUN0RixLQUFLLGNBQVksU0FBUyxLQUFLLENBQUMsRUFDaEMsS0FBSyxVQUFRO0FBQ2IsY0FBTSxPQUFtQixLQUFLO0FBQzlCLFlBQUksT0FBTyxTQUFTLGFBQWE7QUFDL0IsZ0JBQU0sU0FBc0IsQ0FBQyxDQUFDLEtBQUssU0FBUyxPQUFPLEtBQUssT0FBTyxDQUFDO0FBQ2hFLGlCQUFPO0FBQUEsUUFDVDtBQUNBLGVBQU87QUFBQSxNQUNSLENBQUMsRUFDQSxNQUFNLE9BQUs7QUFDWCxnQkFBUSxJQUFJLENBQUM7QUFDYixlQUFPLENBQUMsQ0FBQyw2Q0FBNkMsQ0FBQztBQUFBLE1BQ3hELENBQUM7QUFDRCxhQUFPO0FBQUEsSUFDUjtBQUFBLEVBQ0Y7QUFDRjsiLCJuYW1lcyI6W119