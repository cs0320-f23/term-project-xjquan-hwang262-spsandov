import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLHistory.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=07f3bef4"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/jakestifelman/CS32Local/maps-jstifel1-xjquan/frontend/src/components/REPLHistory.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css";
function makeHTMLTable(myArray) {
  return /* @__PURE__ */ jsxDEV("table", { className: "centered-table", tabIndex: 0, children: /* @__PURE__ */ jsxDEV("tbody", { tabIndex: 0, children: myArray.map((row, rowIndex) => /* @__PURE__ */ jsxDEV("tr", { children: row.map((cell, cellIndex) => /* @__PURE__ */ jsxDEV("td", { className: "table-cell", children: cell }, cellIndex, false, {
    fileName: "/Users/jakestifelman/CS32Local/maps-jstifel1-xjquan/frontend/src/components/REPLHistory.tsx",
    lineNumber: 17,
    columnNumber: 45
  }, this)) }, rowIndex, false, {
    fileName: "/Users/jakestifelman/CS32Local/maps-jstifel1-xjquan/frontend/src/components/REPLHistory.tsx",
    lineNumber: 16,
    columnNumber: 43
  }, this)) }, void 0, false, {
    fileName: "/Users/jakestifelman/CS32Local/maps-jstifel1-xjquan/frontend/src/components/REPLHistory.tsx",
    lineNumber: 15,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/Users/jakestifelman/CS32Local/maps-jstifel1-xjquan/frontend/src/components/REPLHistory.tsx",
    lineNumber: 14,
    columnNumber: 10
  }, this);
}
export function REPLHistory(props) {
  if (props.outputMode == "verbose") {
    return /* @__PURE__ */ jsxDEV("div", { className: "repl-history", "aria-live": "assertive", children: props.history.map((item, index) => /* @__PURE__ */ jsxDEV("div", { tabIndex: 0, children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        "Command: ",
        item.command
      ] }, void 0, true, {
        fileName: "/Users/jakestifelman/CS32Local/maps-jstifel1-xjquan/frontend/src/components/REPLHistory.tsx",
        lineNumber: 31,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "Result: ",
        makeHTMLTable(item.result)
      ] }, void 0, true, {
        fileName: "/Users/jakestifelman/CS32Local/maps-jstifel1-xjquan/frontend/src/components/REPLHistory.tsx",
        lineNumber: 34,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/jakestifelman/CS32Local/maps-jstifel1-xjquan/frontend/src/components/REPLHistory.tsx",
        lineNumber: 37,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("hr", { className: "output-separator" }, void 0, false, {
        fileName: "/Users/jakestifelman/CS32Local/maps-jstifel1-xjquan/frontend/src/components/REPLHistory.tsx",
        lineNumber: 38,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jakestifelman/CS32Local/maps-jstifel1-xjquan/frontend/src/components/REPLHistory.tsx",
      lineNumber: 30,
      columnNumber: 53
    }, this)) }, void 0, false, {
      fileName: "/Users/jakestifelman/CS32Local/maps-jstifel1-xjquan/frontend/src/components/REPLHistory.tsx",
      lineNumber: 26,
      columnNumber: 12
    }, this);
  } else {
    return /* @__PURE__ */ jsxDEV("div", { className: "repl-history", "aria-live": "assertive", children: props.history.map((item, index) => /* @__PURE__ */ jsxDEV("div", { tabIndex: 0, children: [
      "Result: ",
      makeHTMLTable(item.result),
      /* @__PURE__ */ jsxDEV("hr", { className: "output-separator" }, void 0, false, {
        fileName: "/Users/jakestifelman/CS32Local/maps-jstifel1-xjquan/frontend/src/components/REPLHistory.tsx",
        lineNumber: 49,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jakestifelman/CS32Local/maps-jstifel1-xjquan/frontend/src/components/REPLHistory.tsx",
      lineNumber: 47,
      columnNumber: 53
    }, this)) }, void 0, false, {
      fileName: "/Users/jakestifelman/CS32Local/maps-jstifel1-xjquan/frontend/src/components/REPLHistory.tsx",
      lineNumber: 43,
      columnNumber: 12
    }, this);
  }
}
_c = REPLHistory;
var _c;
$RefreshReg$(_c, "REPLHistory");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jakestifelman/CS32Local/maps-jstifel1-xjquan/frontend/src/components/REPLHistory.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JnQjtBQXBCaEIsT0FBTyxvQkFBb0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFhM0IsU0FBU0EsY0FBY0MsU0FBcUI7QUFDeEMsU0FDRSx1QkFBQyxXQUFNLFdBQVUsa0JBQWlCLFVBQVUsR0FDMUMsaUNBQUMsV0FBTSxVQUFVLEdBQ2RBLGtCQUFRQyxJQUFJLENBQUNDLEtBQUtDLGFBQ2pCLHVCQUFDLFFBQ0VELGNBQUlELElBQUksQ0FBQ0csTUFBTUMsY0FDZCx1QkFBQyxRQUFtQixXQUFVLGNBQWNELGtCQUFuQ0MsV0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWlELENBQ2xELEtBSE1GLFVBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUlBLENBQ0QsS0FQSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBVUE7QUFFSjtBQUVLLGdCQUFTRyxZQUFZQyxPQUEwQjtBQUNsRCxNQUFHQSxNQUFNQyxjQUFjLFdBQVc7QUFFOUIsV0FDSSx1QkFBQyxTQUFJLFdBQVUsZ0JBQWUsYUFBVSxhQUluQ0QsZ0JBQU1FLFFBQVFSLElBQUksQ0FBQ1MsTUFBTUMsVUFDdEIsdUJBQUMsU0FBSSxVQUFVLEdBQ1g7QUFBQSw2QkFBQyxTQUFHO0FBQUE7QUFBQSxRQUNVRCxLQUFLRTtBQUFBQSxXQURuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUc7QUFBQTtBQUFBLFFBQ1NiLGNBQWNXLEtBQUtHLE1BQU07QUFBQSxXQUR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFHO0FBQUEsTUFDSCx1QkFBQyxRQUFHLFdBQVUsc0JBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQztBQUFBLFNBUnBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQSxDQUNILEtBZkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdCQTtBQUFBLEVBRVIsT0FBTztBQUVILFdBQ0ksdUJBQUMsU0FBSSxXQUFVLGdCQUFlLGFBQVUsYUFJbkNOLGdCQUFNRSxRQUFRUixJQUFJLENBQUNTLE1BQU1DLFVBQ3RCLHVCQUFDLFNBQUksVUFBVSxHQUFFO0FBQUE7QUFBQSxNQUNKWixjQUFjVyxLQUFLRyxNQUFNO0FBQUEsTUFDbEMsdUJBQUMsUUFBRyxXQUFVLHNCQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0M7QUFBQSxTQUZwQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0EsQ0FDSCxLQVRMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLEVBRVA7QUFDTDtBQUFDQyxLQXRDZVI7QUFBVyxJQUFBUTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsibWFrZUhUTUxUYWJsZSIsIm15QXJyYXkiLCJtYXAiLCJyb3ciLCJyb3dJbmRleCIsImNlbGwiLCJjZWxsSW5kZXgiLCJSRVBMSGlzdG9yeSIsInByb3BzIiwib3V0cHV0TW9kZSIsImhpc3RvcnkiLCJpdGVtIiwiaW5kZXgiLCJjb21tYW5kIiwicmVzdWx0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSRVBMSGlzdG9yeS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICcuLi9zdHlsZXMvbWFpbi5jc3MnO1xuXG5pbnRlcmZhY2UgSGlzdG9yeU9iamVjdCB7XG4gICAgY29tbWFuZDogc3RyaW5nO1xuICAgIHJlc3VsdDogc3RyaW5nW11bXTtcbiAgfVxuaW50ZXJmYWNlIFJFUExIaXN0b3J5UHJvcHN7XG4gICAgLy8gVE9ETzogRmlsbCB3aXRoIHNvbWUgc2hhcmVkIHN0YXRlIHRyYWNraW5nIGFsbCB0aGUgcHVzaGVkIGNvbW1hbmRzXG4gICAgLy8gQ0hBTkdFRFxuICAgIGhpc3Rvcnk6IEhpc3RvcnlPYmplY3RbXVxuICAgIG91dHB1dE1vZGU6IHN0cmluZztcbn1cbi8vIFR1cm4gYWxsIGhpc3RvcnkgZWxlbWVudHMgaW50byBhbiBodG1sIHRhYmxlXG5mdW5jdGlvbiBtYWtlSFRNTFRhYmxlKG15QXJyYXk6IHN0cmluZ1tdW10pIHtcbiAgICByZXR1cm4gKFxuICAgICAgPHRhYmxlIGNsYXNzTmFtZT0nY2VudGVyZWQtdGFibGUnIHRhYkluZGV4PXswfT5cbiAgICAgICAgPHRib2R5IHRhYkluZGV4PXswfT5cbiAgICAgICAgICB7bXlBcnJheS5tYXAoKHJvdywgcm93SW5kZXgpID0+IChcbiAgICAgICAgICAgIDx0ciBrZXk9e3Jvd0luZGV4fT5cbiAgICAgICAgICAgICAge3Jvdy5tYXAoKGNlbGwsIGNlbGxJbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgIDx0ZCBrZXk9e2NlbGxJbmRleH0gY2xhc3NOYW1lPSd0YWJsZS1jZWxsJz57Y2VsbH08L3RkPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvdGJvZHk+XG4gICAgICA8L3RhYmxlPlxuICAgICk7XG4gIH1cbiAgLy9HZW5lcmF0ZSBIaXN0b3J5XG5leHBvcnQgZnVuY3Rpb24gUkVQTEhpc3RvcnkocHJvcHMgOiBSRVBMSGlzdG9yeVByb3BzKSB7XG4gICAgaWYocHJvcHMub3V0cHV0TW9kZSA9PSBcInZlcmJvc2VcIikge1xuICAgICAgLy9hcmlhLWxpdmU9XCJhc3NlcnRpdmVcIiBhcmlhLWF0b21pYz1cInRydWVcIlxuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZXBsLWhpc3RvcnlcIiBhcmlhLWxpdmU9XCJhc3NlcnRpdmVcIj5cbiAgICAgICAgICAgICAgICB7LyogVGhpcyBpcyB3aGVyZSBjb21tYW5kIGhpc3Rvcnkgd2lsbCBnbyAqL31cbiAgICAgICAgICAgICAgICB7LyogVE9ETzogVG8gZ28gdGhyb3VnaCBhbGwgdGhlIHB1c2hlZCBjb21tYW5kcy4uLiB0cnkgdGhlIC5tYXAoKSBmdW5jdGlvbiEgKi99XG4gICAgICAgICAgICAgICAgey8qIENIQU5HRUQgKi99XG4gICAgICAgICAgICAgICAge3Byb3BzLmhpc3RvcnkubWFwKChpdGVtLCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IHRhYkluZGV4PXswfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQ29tbWFuZDoge2l0ZW0uY29tbWFuZH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBSZXN1bHQ6IHttYWtlSFRNTFRhYmxlKGl0ZW0ucmVzdWx0KX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGJyIC8+IFxuICAgICAgICAgICAgICAgICAgICAgICAgPGhyIGNsYXNzTmFtZT1cIm91dHB1dC1zZXBhcmF0b3JcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICApO1xuICAgIH0gZWxzZSB7XG4gICAgICAvL2FyaWEtbGl2ZT1cImFzc2VydGl2ZVwiIGFyaWEtYXRvbWljPVwidHJ1ZVwiXG4gICAgICAgIHJldHVybihcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVwbC1oaXN0b3J5XCIgYXJpYS1saXZlPVwiYXNzZXJ0aXZlXCI+XG4gICAgICAgICAgICAgICAgey8qIFRoaXMgaXMgd2hlcmUgY29tbWFuZCBoaXN0b3J5IHdpbGwgZ28gKi99XG4gICAgICAgICAgICAgICAgey8qIFRPRE86IFRvIGdvIHRocm91Z2ggYWxsIHRoZSBwdXNoZWQgY29tbWFuZHMuLi4gdHJ5IHRoZSAubWFwKCkgZnVuY3Rpb24hICovfVxuICAgICAgICAgICAgICAgIHsvKiBDSEFOR0VEICovfVxuICAgICAgICAgICAgICAgIHtwcm9wcy5oaXN0b3J5Lm1hcCgoaXRlbSwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiB0YWJJbmRleD17MH0+XG4gICAgICAgICAgICAgICAgICAgICAgICBSZXN1bHQ6IHttYWtlSFRNTFRhYmxlKGl0ZW0ucmVzdWx0KX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDxociBjbGFzc05hbWU9XCJvdXRwdXQtc2VwYXJhdG9yXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKTtcbiAgICAgfVxufSJdLCJmaWxlIjoiL1VzZXJzL2pha2VzdGlmZWxtYW4vQ1MzMkxvY2FsL21hcHMtanN0aWZlbDEteGpxdWFuL2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL1JFUExIaXN0b3J5LnRzeCJ9