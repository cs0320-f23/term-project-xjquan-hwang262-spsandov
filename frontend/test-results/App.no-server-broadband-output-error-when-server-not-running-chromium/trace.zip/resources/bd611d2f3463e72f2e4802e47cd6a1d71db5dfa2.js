export function handleBroadbandCommand(args) {
  if (args.length < 2) {
    return new Promise((resolve) => {
      resolve([[
        "Error - Too Few Arguments, Add a <state> and <county> for broadband retrieval"
      ]]);
    });
  } else {
    const [state, county, ...rest] = args;
    if (rest.length !== 0) {
      return new Promise((resolve) => {
        resolve([[
          "Error - Do Not Enter Args Other Than State and County"
        ]]);
      });
    } else {
      const OR = fetch(`http://localhost:8080/broadband?state=${state}&county=${county}`).then((response) => response.json()).then((json) => {
        console.log(json);
        const broadband = [["broadband", "date & time"], [json.broadband, json["date & time"]]];
        console.log(broadband);
        console.log(typeof broadband);
        if (typeof broadband[1][0] === "undefined") {
          const result = [[json.result + ": " + json.message]];
          return result;
        }
        return broadband;
      }).catch((e) => {
        console.log(e);
        return [["Error with data fetching for broadband request"]];
      });
      return OR;
    }
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJyb2FkYmFuZENvbW1hbmQudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUkVQTElucHV0UHJvcHMgfSBmcm9tIFwiLi4vY29tcG9uZW50cy9SRVBMSW5wdXRcIjtcblxuLy8gaGFuZGxlIHRoZSAnYnJvYWRiYW5kJyBjb21tYW5kIGFuZCByZXRyaWV2ZSBjZW5zdXMgQVBJIGRhdGEgZm9yIHNwZWNpZmljIGNvdW50eSBhbmQgc3RhdGUgY29tYmluYXRpb25zXG5leHBvcnQgZnVuY3Rpb24gaGFuZGxlQnJvYWRiYW5kQ29tbWFuZChhcmdzOiBBcnJheTxzdHJpbmc+KTogUHJvbWlzZTxzdHJpbmdbXVtdPiB7XG4gICAgaWYgKGFyZ3MubGVuZ3RoIDwgMikge1xuICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKHJlc29sdmUgPT4geyBcbiAgICAgICAgcmVzb2x2ZShbW1xuICAgICAgICAgIFwiRXJyb3IgLSBUb28gRmV3IEFyZ3VtZW50cywgQWRkIGEgPHN0YXRlPiBhbmQgPGNvdW50eT4gZm9yIGJyb2FkYmFuZCByZXRyaWV2YWxcIixcbiAgICAgICAgXV0pO1xuICAgICAgfSlcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgW3N0YXRlLCBjb3VudHksIC4uLnJlc3RdID0gYXJncztcbiAgICAgIGlmIChyZXN0Lmxlbmd0aCAhPT0gMCkge1xuICAgICAgICByZXR1cm4gbmV3IFByb21pc2UocmVzb2x2ZSA9PiB7IFxuICAgICAgICAgIHJlc29sdmUoW1tcbiAgICAgICAgICAgIFwiRXJyb3IgLSBEbyBOb3QgRW50ZXIgQXJncyBPdGhlciBUaGFuIFN0YXRlIGFuZCBDb3VudHlcIixcbiAgICAgICAgICBdXSk7XG4gICAgICAgIH0pXG4gICAgICB9IGVsc2Uge1xuICAgICAgIGNvbnN0IE9SID0gZmV0Y2goYGh0dHA6Ly9sb2NhbGhvc3Q6ODA4MC9icm9hZGJhbmQ/c3RhdGU9JHtzdGF0ZX0mY291bnR5PSR7Y291bnR5fWApXG4gICAgICAgLnRoZW4ocmVzcG9uc2UgPT4gcmVzcG9uc2UuanNvbigpKVxuICAgICAgIC50aGVuKGpzb24gPT4ge1xuICAgICAgICBjb25zb2xlLmxvZyhqc29uKVxuICAgICAgICBjb25zdCBicm9hZGJhbmQ6IHN0cmluZ1tdW10gPSBbW1wiYnJvYWRiYW5kXCIsIFwiZGF0ZSAmIHRpbWVcIl0sIFtqc29uLmJyb2FkYmFuZCwganNvbltcImRhdGUgJiB0aW1lXCJdXV1cbiAgICAgICAgY29uc29sZS5sb2coYnJvYWRiYW5kKVxuICAgICAgICBjb25zb2xlLmxvZyh0eXBlb2YgYnJvYWRiYW5kKVxuICAgICAgICBpZiAodHlwZW9mIGJyb2FkYmFuZFsxXVswXSA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA6IHN0cmluZ1tdW10gPSBbW2pzb24ucmVzdWx0ICsgXCI6IFwiICsganNvbi5tZXNzYWdlXV1cbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGJyb2FkYmFuZDtcbiAgICAgICB9KVxuICAgICAgIC5jYXRjaChlID0+IHtcbiAgICAgICAgY29uc29sZS5sb2coZSlcbiAgICAgICAgcmV0dXJuIFtbXCJFcnJvciB3aXRoIGRhdGEgZmV0Y2hpbmcgZm9yIGJyb2FkYmFuZCByZXF1ZXN0XCJdXVxuICAgICAgIH0pXG4gICAgICAgcmV0dXJuIE9SO1xuICAgICAgfVxuICAgIH1cbiAgfSJdLCJtYXBwaW5ncyI6IkFBR08sZ0JBQVMsdUJBQXVCLE1BQTBDO0FBQzdFLE1BQUksS0FBSyxTQUFTLEdBQUc7QUFDbkIsV0FBTyxJQUFJLFFBQVEsYUFBVztBQUM1QixjQUFRLENBQUM7QUFBQSxRQUNQO0FBQUEsTUFDRixDQUFDLENBQUM7QUFBQSxJQUNKLENBQUM7QUFBQSxFQUNILE9BQU87QUFDTCxVQUFNLENBQUMsT0FBTyxRQUFRLEdBQUcsSUFBSSxJQUFJO0FBQ2pDLFFBQUksS0FBSyxXQUFXLEdBQUc7QUFDckIsYUFBTyxJQUFJLFFBQVEsYUFBVztBQUM1QixnQkFBUSxDQUFDO0FBQUEsVUFDUDtBQUFBLFFBQ0YsQ0FBQyxDQUFDO0FBQUEsTUFDSixDQUFDO0FBQUEsSUFDSCxPQUFPO0FBQ04sWUFBTSxLQUFLLE1BQU0seUNBQXlDLEtBQUssV0FBVyxNQUFNLEVBQUUsRUFDakYsS0FBSyxjQUFZLFNBQVMsS0FBSyxDQUFDLEVBQ2hDLEtBQUssVUFBUTtBQUNiLGdCQUFRLElBQUksSUFBSTtBQUNoQixjQUFNLFlBQXdCLENBQUMsQ0FBQyxhQUFhLGFBQWEsR0FBRyxDQUFDLEtBQUssV0FBVyxLQUFLLGFBQWEsQ0FBQyxDQUFDO0FBQ2xHLGdCQUFRLElBQUksU0FBUztBQUNyQixnQkFBUSxJQUFJLE9BQU8sU0FBUztBQUM1QixZQUFJLE9BQU8sVUFBVSxDQUFDLEVBQUUsQ0FBQyxNQUFNLGFBQWE7QUFDeEMsZ0JBQU0sU0FBc0IsQ0FBQyxDQUFDLEtBQUssU0FBUyxPQUFPLEtBQUssT0FBTyxDQUFDO0FBQ2hFLGlCQUFPO0FBQUEsUUFDWDtBQUNBLGVBQU87QUFBQSxNQUNSLENBQUMsRUFDQSxNQUFNLE9BQUs7QUFDWCxnQkFBUSxJQUFJLENBQUM7QUFDYixlQUFPLENBQUMsQ0FBQyxnREFBZ0QsQ0FBQztBQUFBLE1BQzNELENBQUM7QUFDRCxhQUFPO0FBQUEsSUFDUjtBQUFBLEVBQ0Y7QUFDRjsiLCJuYW1lcyI6W119