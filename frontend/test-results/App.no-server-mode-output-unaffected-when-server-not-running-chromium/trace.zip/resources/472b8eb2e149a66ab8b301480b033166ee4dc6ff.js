import {
  require_react
} from "/node_modules/.vite/deps/chunk-ZVMIEU5R.js?v=07f3bef4";
import "/node_modules/.vite/deps/chunk-UXIASGQL.js?v=07f3bef4";
export default require_react();
//# sourceMappingURL=react.js.map
