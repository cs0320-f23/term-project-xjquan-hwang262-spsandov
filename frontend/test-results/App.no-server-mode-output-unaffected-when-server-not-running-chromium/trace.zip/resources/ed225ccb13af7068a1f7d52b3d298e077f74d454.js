import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=07f3bef4"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/jakestifelman/CS32Local/maps-jstifel1-xjquan/frontend/src/components/REPLInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/main.css";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=07f3bef4"; const useState = __vite__cjsImport4_react["useState"];
import { ControlledInput } from "/src/components/ControlledInput.tsx";
import { commandsMap } from "/src/commands/commandFunctions.ts";
export function REPLInput(props) {
  _s();
  const [commandString, setCommandString] = useState("");
  const [count, setCount] = useState(0);
  const [csvloaded, setcsvload] = useState(false);
  const [csvdata, setCsvData] = useState([[]]);
  const [header, setHeader] = useState([]);
  const [isHeader, setIsHeader] = useState(false);
  const [filePathSearch, setFilePath] = useState("");
  async function handleSubmit(commandString2) {
    setCount(count + 1);
    const Output = await handleOutput(commandString2);
    const newHistoryEntry = {
      command: commandString2,
      result: Output
    };
    props.setHistory([...props.history, newHistoryEntry]);
    setCommandString("");
    async function handleOutput(commandString3) {
      const [command, ...args] = commandString3.split(" ");
      const mapFunc = commandsMap.get(command);
      if (typeof mapFunc !== "undefined") {
        return await mapFunc(args, props);
      } else {
        return [["Invalid command: " + command]];
      }
    }
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-input", onKeyDown: (key) => key.code == "Enter" ? handleSubmit(commandString) : null, children: [
    /* @__PURE__ */ jsxDEV("fieldset", { children: [
      /* @__PURE__ */ jsxDEV("legend", { children: "Enter a command:" }, void 0, false, {
        fileName: "/Users/jakestifelman/CS32Local/maps-jstifel1-xjquan/frontend/src/components/REPLInput.tsx",
        lineNumber: 64,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(ControlledInput, { value: commandString, setValue: setCommandString, ariaLabel: "Command input" }, void 0, false, {
        fileName: "/Users/jakestifelman/CS32Local/maps-jstifel1-xjquan/frontend/src/components/REPLInput.tsx",
        lineNumber: 65,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jakestifelman/CS32Local/maps-jstifel1-xjquan/frontend/src/components/REPLInput.tsx",
      lineNumber: 63,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { id: "button", onClick: () => handleSubmit(commandString), children: [
      "Submitted ",
      count,
      " times"
    ] }, void 0, true, {
      fileName: "/Users/jakestifelman/CS32Local/maps-jstifel1-xjquan/frontend/src/components/REPLInput.tsx",
      lineNumber: 67,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jakestifelman/CS32Local/maps-jstifel1-xjquan/frontend/src/components/REPLInput.tsx",
    lineNumber: 62,
    columnNumber: 10
  }, this);
}
_s(REPLInput, "Dj2oWGNpereff49Wgl2E30/XCqk=");
_c = REPLInput;
var _c;
$RefreshReg$(_c, "REPLInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jakestifelman/CS32Local/maps-jstifel1-xjquan/frontend/src/components/REPLInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0RROzs7Ozs7Ozs7Ozs7Ozs7OztBQS9EUixPQUFPO0FBQ1AsU0FBbUNBLGdCQUEyQjtBQUM5RCxTQUFTQyx1QkFBdUI7QUFJaEMsU0FBU0MsbUJBQW9DO0FBaUJ0QyxnQkFBU0MsVUFBVUMsT0FBdUI7QUFBQUMsS0FBQTtBQUUvQyxRQUFNLENBQUNDLGVBQWVDLGdCQUFnQixJQUFJUCxTQUFpQixFQUFFO0FBRTdELFFBQU0sQ0FBQ1EsT0FBT0MsUUFBUSxJQUFJVCxTQUFpQixDQUFDO0FBRTVDLFFBQU0sQ0FBQ1UsV0FBV0MsVUFBVSxJQUFJWCxTQUFrQixLQUFLO0FBQ3ZELFFBQU0sQ0FBQ1ksU0FBU0MsVUFBVSxJQUFJYixTQUFxQixDQUFDLEVBQUUsQ0FBQztBQUN2RCxRQUFNLENBQUNjLFFBQVFDLFNBQVMsSUFBSWYsU0FBbUIsRUFBRTtBQUNqRCxRQUFNLENBQUNnQixVQUFVQyxXQUFXLElBQUlqQixTQUFrQixLQUFLO0FBQ3ZELFFBQU0sQ0FBQ2tCLGdCQUFnQkMsV0FBVyxJQUFJbkIsU0FBaUIsRUFBRTtBQUd6RCxpQkFBZW9CLGFBQWFkLGdCQUF1QjtBQUNqREcsYUFBU0QsUUFBUSxDQUFDO0FBQ2xCLFVBQU1hLFNBQXFCLE1BQU1DLGFBQWFoQixjQUFhO0FBQzNELFVBQU1pQixrQkFBaUM7QUFBQSxNQUNyQ0MsU0FBU2xCO0FBQUFBLE1BQ1RtQixRQUFRSjtBQUFBQSxJQUNWO0FBRUFqQixVQUFNc0IsV0FBVyxDQUFDLEdBQUd0QixNQUFNdUIsU0FBU0osZUFBZSxDQUFDO0FBQ3BEaEIscUJBQWlCLEVBQUU7QUFHbkIsbUJBQWVlLGFBQWFoQixnQkFBdUI7QUFDakQsWUFBTSxDQUFDa0IsU0FBUyxHQUFHSSxJQUFJLElBQUl0QixlQUFjdUIsTUFBTSxHQUFHO0FBQ2xELFlBQU1DLFVBQVU1QixZQUFZNkIsSUFBSVAsT0FBTztBQUN2QyxVQUFJLE9BQU9NLFlBQVksYUFBYTtBQUNsQyxlQUFPLE1BQU1BLFFBQVFGLE1BQU14QixLQUFLO0FBQUEsTUFDbEMsT0FBTztBQUNMLGVBQU8sQ0FBQyxDQUFDLHNCQUFzQm9CLE9BQU8sQ0FBQztBQUFBLE1BQ3pDO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFHQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxjQUFhLFdBQVlRLFNBQVFBLElBQUlDLFFBQVEsVUFBVWIsYUFBYWQsYUFBYSxJQUFHLE1BQ2pHO0FBQUEsMkJBQUMsY0FDQztBQUFBLDZCQUFDLFlBQU8sZ0NBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3QjtBQUFBLE1BQ3hCLHVCQUFDLG1CQUNDLE9BQU9BLGVBQ1AsVUFBVUMsa0JBQ1YsV0FBVyxtQkFIYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRzZCO0FBQUEsU0FML0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsSUFDQSx1QkFBQyxZQUNELElBQUcsVUFDSCxTQUFTLE1BQU1hLGFBQWFkLGFBQWEsR0FBRTtBQUFBO0FBQUEsTUFDOUJFO0FBQUFBLE1BQU07QUFBQSxTQUhuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxPQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FjQTtBQUVKO0FBQUNILEdBdERlRixXQUFTO0FBQUErQixLQUFUL0I7QUFBUyxJQUFBK0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiQ29udHJvbGxlZElucHV0IiwiY29tbWFuZHNNYXAiLCJSRVBMSW5wdXQiLCJwcm9wcyIsIl9zIiwiY29tbWFuZFN0cmluZyIsInNldENvbW1hbmRTdHJpbmciLCJjb3VudCIsInNldENvdW50IiwiY3N2bG9hZGVkIiwic2V0Y3N2bG9hZCIsImNzdmRhdGEiLCJzZXRDc3ZEYXRhIiwiaGVhZGVyIiwic2V0SGVhZGVyIiwiaXNIZWFkZXIiLCJzZXRJc0hlYWRlciIsImZpbGVQYXRoU2VhcmNoIiwic2V0RmlsZVBhdGgiLCJoYW5kbGVTdWJtaXQiLCJPdXRwdXQiLCJoYW5kbGVPdXRwdXQiLCJuZXdIaXN0b3J5RW50cnkiLCJjb21tYW5kIiwicmVzdWx0Iiwic2V0SGlzdG9yeSIsImhpc3RvcnkiLCJhcmdzIiwic3BsaXQiLCJtYXBGdW5jIiwiZ2V0Iiwia2V5IiwiY29kZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVQTElucHV0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgXCIuLi9zdHlsZXMvbWFpbi5jc3NcIjtcbmltcG9ydCB7IERpc3BhdGNoLCBTZXRTdGF0ZUFjdGlvbiwgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgQ29udHJvbGxlZElucHV0IH0gZnJvbSBcIi4vQ29udHJvbGxlZElucHV0XCI7XG5pbXBvcnQgeyBtb2NrQmFja2VuZERhdGEgfSBmcm9tIFwiLi4vbW9ja2VkX2RhdGEvbW9ja2VkSnNvblwiO1xuaW1wb3J0IHsgbW9ja2VkU2VhcmNoUmVzdWx0cyB9IGZyb20gXCIuLi9tb2NrZWRfZGF0YS9tb2NrZWRTZWFyY2hKc29uXCI7XG5pbXBvcnQgeyBqc29uIH0gZnJvbSBcInN0cmVhbS9jb25zdW1lcnNcIjtcbmltcG9ydCB7IGNvbW1hbmRzTWFwLCByZWdpc3RlckNvbW1hbmQgfSBmcm9tIFwiLi4vY29tbWFuZHMvY29tbWFuZEZ1bmN0aW9uc1wiXG5cbi8vIERlZmluZSB0aGUgc2hhcGUgb2YgaGlzdG9yeSBlbnRyaWVzXG5pbnRlcmZhY2UgSGlzdG9yeU9iamVjdCB7XG4gIGNvbW1hbmQ6IHN0cmluZztcbiAgcmVzdWx0OiBzdHJpbmdbXVtdO1xufVxuXG4vLyBEZWZpbmUgdGhlIHByb3BlcnRpZXMgZm9yIHRoZSBSRVBMSW5wdXQgY29tcG9uZW50XG5leHBvcnQgaW50ZXJmYWNlIFJFUExJbnB1dFByb3BzIHtcbiAgaGlzdG9yeTogSGlzdG9yeU9iamVjdFtdO1xuICBzZXRIaXN0b3J5OiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxIaXN0b3J5T2JqZWN0W10+PjtcbiAgb3V0cHV0TW9kZTogc3RyaW5nO1xuICBzZXRPdXRwdXRNb2RlOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxzdHJpbmc+Pjtcbn1cblxuLy8gVGhlIFJFUExJbnB1dCBjb21wb25lbnQgZm9yIGhhbmRsaW5nIHVzZXIgaW5wdXQgYW5kIGNvbW1hbmQgZXhlY3V0aW9uXG5leHBvcnQgZnVuY3Rpb24gUkVQTElucHV0KHByb3BzOiBSRVBMSW5wdXRQcm9wcykge1xuICAvLyBNYW5hZ2UgdGhlIGNvbnRlbnRzIG9mIHRoZSBpbnB1dCBib3hcbiAgY29uc3QgW2NvbW1hbmRTdHJpbmcsIHNldENvbW1hbmRTdHJpbmddID0gdXNlU3RhdGU8c3RyaW5nPihcIlwiKTtcbiAgLy8gTWFuYWdlIHRoZSBjdXJyZW50IGNvdW50IG9mIHRpbWVzIHRoZSBidXR0b24gaXMgY2xpY2tlZFxuICBjb25zdCBbY291bnQsIHNldENvdW50XSA9IHVzZVN0YXRlPG51bWJlcj4oMCk7XG4gIC8vIE1hbmFnZSB0aGUgc3RhdGUgb2YgQ1NWIGRhdGEgbG9hZGluZ1xuICBjb25zdCBbY3N2bG9hZGVkLCBzZXRjc3Zsb2FkXSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKTtcbiAgY29uc3QgW2NzdmRhdGEsIHNldENzdkRhdGFdID0gdXNlU3RhdGU8c3RyaW5nW11bXT4oW1tdXSk7XG4gIGNvbnN0IFtoZWFkZXIsIHNldEhlYWRlcl0gPSB1c2VTdGF0ZTxzdHJpbmdbXT4oW10pO1xuICBjb25zdCBbaXNIZWFkZXIsIHNldElzSGVhZGVyXSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKTtcbiAgY29uc3QgW2ZpbGVQYXRoU2VhcmNoLCBzZXRGaWxlUGF0aF0gPSB1c2VTdGF0ZTxzdHJpbmc+KFwiXCIpO1xuXG4gIC8vIEhhbmRsZSB0aGUgc3VibWlzc2lvbiBvZiBhIGNvbW1hbmQgc3RyaW5nXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZVN1Ym1pdChjb21tYW5kU3RyaW5nOiBzdHJpbmcpIHtcbiAgICBzZXRDb3VudChjb3VudCArIDEpO1xuICAgIGNvbnN0IE91dHB1dDogc3RyaW5nW11bXSA9IGF3YWl0IGhhbmRsZU91dHB1dChjb21tYW5kU3RyaW5nKTtcbiAgICBjb25zdCBuZXdIaXN0b3J5RW50cnk6IEhpc3RvcnlPYmplY3QgPSB7XG4gICAgICBjb21tYW5kOiBjb21tYW5kU3RyaW5nLFxuICAgICAgcmVzdWx0OiBPdXRwdXQsXG4gICAgfTtcblxuICAgIHByb3BzLnNldEhpc3RvcnkoWy4uLnByb3BzLmhpc3RvcnksIG5ld0hpc3RvcnlFbnRyeV0pO1xuICAgIHNldENvbW1hbmRTdHJpbmcoXCJcIik7XG5cbiAgICAvLyBIYW5kbGUgdGhlIG91dHB1dCBmb3IgdGhlIGdpdmVuIGNvbW1hbmRcbiAgICBhc3luYyBmdW5jdGlvbiBoYW5kbGVPdXRwdXQoY29tbWFuZFN0cmluZzogc3RyaW5nKSB7XG4gICAgICBjb25zdCBbY29tbWFuZCwgLi4uYXJnc10gPSBjb21tYW5kU3RyaW5nLnNwbGl0KFwiIFwiKTtcbiAgICAgIGNvbnN0IG1hcEZ1bmMgPSBjb21tYW5kc01hcC5nZXQoY29tbWFuZClcbiAgICAgIGlmICh0eXBlb2YgbWFwRnVuYyAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgcmV0dXJuIGF3YWl0IG1hcEZ1bmMoYXJncywgcHJvcHMpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIFtbXCJJbnZhbGlkIGNvbW1hbmQ6IFwiICsgY29tbWFuZF1dO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC8vb25LZXlEb3duPXsoa2V5KSA9PiBrZXkuY29kZSA9PSBcIkVudGVyXCIgPyBoYW5kbGVTdWJtaXQoY29tbWFuZFN0cmluZyk6IG51bGx9XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZXBsLWlucHV0XCIgb25LZXlEb3duPXsoa2V5KSA9PiBrZXkuY29kZSA9PSBcIkVudGVyXCIgPyBoYW5kbGVTdWJtaXQoY29tbWFuZFN0cmluZyk6IG51bGx9PlxuICAgICAgPGZpZWxkc2V0PlxuICAgICAgICA8bGVnZW5kPkVudGVyIGEgY29tbWFuZDo8L2xlZ2VuZD5cbiAgICAgICAgPENvbnRyb2xsZWRJbnB1dFxuICAgICAgICAgIHZhbHVlPXtjb21tYW5kU3RyaW5nfVxuICAgICAgICAgIHNldFZhbHVlPXtzZXRDb21tYW5kU3RyaW5nfVxuICAgICAgICAgIGFyaWFMYWJlbD17XCJDb21tYW5kIGlucHV0XCJ9XG4gICAgICAgIC8+XG4gICAgICA8L2ZpZWxkc2V0PlxuICAgICAgPGJ1dHRvbiBcbiAgICAgIGlkPVwiYnV0dG9uXCIgXG4gICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTdWJtaXQoY29tbWFuZFN0cmluZyl9PlxuICAgICAgICBTdWJtaXR0ZWQge2NvdW50fSB0aW1lc1xuICAgICAgPC9idXR0b24+XG4gICAgPC9kaXY+XG4gICk7XG59Il0sImZpbGUiOiIvVXNlcnMvamFrZXN0aWZlbG1hbi9DUzMyTG9jYWwvbWFwcy1qc3RpZmVsMS14anF1YW4vZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvUkVQTElucHV0LnRzeCJ9