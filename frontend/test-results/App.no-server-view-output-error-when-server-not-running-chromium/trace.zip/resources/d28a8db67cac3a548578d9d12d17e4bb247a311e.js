import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/Map/WrappedMap.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=07f3bef4"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/jakestifelman/CS32Local/maps-jstifel1-xjquan/frontend/src/Map/WrappedMap.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import Map, { Layer, Source } from "/node_modules/.vite/deps/react-map-gl.js?v=07f3bef4";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=07f3bef4"; const useState = __vite__cjsImport4_react["useState"]; const useEffect = __vite__cjsImport4_react["useEffect"];
import { api_key } from "/src/Private/Token.tsx";
import { geoLayer, overlayData } from "/src/Map/Overlay.tsx";
import { getFetchedData, overlaySpecialData } from "/src/commands/areaCommand.ts";
function WrappedMap() {
  _s();
  const [viewState, setViewState] = useState({
    longitude: -71.418884,
    latitude: 41.825226,
    zoom: 12
  });
  const [overlay, setOverlay] = useState(void 0);
  useEffect(() => {
    const fetchData = async () => {
      const regularOverlay = overlayData();
      const specialOverlay = await overlaySpecialData();
      setOverlay(getFetchedData() ? specialOverlay : regularOverlay);
    };
    fetchData();
  }, [getFetchedData(), overlaySpecialData(), overlayData()]);
  return /* @__PURE__ */ jsxDEV(Map, { longitude: viewState.longitude, latitude: viewState.latitude, zoom: viewState.zoom, mapboxAccessToken: api_key, onMove: (ev) => setViewState(ev.viewState), style: {
    width: window.innerWidth,
    height: window.innerHeight
  }, mapStyle: "mapbox://styles/mapbox/streets-v12", children: /* @__PURE__ */ jsxDEV(Source, { id: "geo_data", type: "geojson", data: overlay, children: /* @__PURE__ */ jsxDEV(Layer, { ...geoLayer }, void 0, false, {
    fileName: "/Users/jakestifelman/CS32Local/maps-jstifel1-xjquan/frontend/src/Map/WrappedMap.tsx",
    lineNumber: 46,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/Users/jakestifelman/CS32Local/maps-jstifel1-xjquan/frontend/src/Map/WrappedMap.tsx",
    lineNumber: 45,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jakestifelman/CS32Local/maps-jstifel1-xjquan/frontend/src/Map/WrappedMap.tsx",
    lineNumber: 40,
    columnNumber: 10
  }, this);
}
_s(WrappedMap, "6DWsRt+AYOmKIYs0iQBjbXl85rc=");
_c = WrappedMap;
function onMapClick(e) {
  console.log(e);
  console.log(e.lngLat.lat);
  console.log(e.lngLat.lng);
}
export default WrappedMap;
var _c;
$RefreshReg$(_c, "WrappedMap");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jakestifelman/CS32Local/maps-jstifel1-xjquan/frontend/src/Map/WrappedMap.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMERROzs7Ozs7Ozs7Ozs7Ozs7OztBQTFEUixPQUFPQSxPQUNMQyxPQUVBQyxjQUVLO0FBQ1AsU0FBZ0JDLFVBQVVDLGlCQUFpQjtBQUMzQyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLFVBQVVDLG1CQUFtQjtBQUN0QyxTQUFTQyxnQkFBZ0JDLDBCQUEwQjtBQUtuRCxTQUFTQyxhQUFhO0FBQUFDLEtBQUE7QUFFcEIsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUlWLFNBQVM7QUFBQSxJQUN6Q1csV0FBVztBQUFBLElBQ1hDLFVBQVU7QUFBQSxJQUNWQyxNQUFNO0FBQUEsRUFDUixDQUFDO0FBRUQsUUFBTSxDQUFDQyxTQUFTQyxVQUFVLElBQUlmLFNBQzVCZ0IsTUFDRjtBQU1BZixZQUFVLE1BQU07QUFDZCxVQUFNZ0IsWUFBWSxZQUFZO0FBRTVCLFlBQU1DLGlCQUFpQmQsWUFBWTtBQUNuQyxZQUFNZSxpQkFBaUIsTUFBTWIsbUJBQW1CO0FBSWhEUyxpQkFBV1YsZUFBZSxJQUFJYyxpQkFBaUJELGNBQWM7QUFBQSxJQUMvRDtBQUNBRCxjQUFVO0FBQUEsRUFDWixHQUFHLENBQUNaLGVBQWUsR0FBR0MsbUJBQW1CLEdBQUdGLFlBQVksQ0FBQyxDQUFDO0FBSzFELFNBQ0UsdUJBQUMsT0FDQyxXQUFXSyxVQUFVRSxXQUNyQixVQUFVRixVQUFVRyxVQUNwQixNQUFNSCxVQUFVSSxNQUNoQixtQkFBbUJYLFNBQ25CLFFBQVEsQ0FBQ2tCLE9BQTZCVixhQUFhVSxHQUFHWCxTQUFTLEdBQy9ELE9BQU87QUFBQSxJQUFFWSxPQUFPQyxPQUFPQztBQUFBQSxJQUFZQyxRQUFRRixPQUFPRztBQUFBQSxFQUFZLEdBQzlELFVBQVUsc0NBR1YsaUNBQUMsVUFBTyxJQUFHLFlBQVcsTUFBSyxXQUFVLE1BQU1YLFNBQ3pDLGlDQUFDLFNBQU0sR0FBSVgsWUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQW9CLEtBRHRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQSxLQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FhQTtBQUVKO0FBRUFLLEdBbERTRCxZQUFVO0FBQUFtQixLQUFWbkI7QUFzRFQsU0FBU29CLFdBQVdDLEdBQXVCO0FBQ3pDQyxVQUFRQyxJQUFJRixDQUFDO0FBQ2JDLFVBQVFDLElBQUlGLEVBQUVHLE9BQU9DLEdBQUc7QUFDeEJILFVBQVFDLElBQUlGLEVBQUVHLE9BQU9FLEdBQUc7QUFDMUI7QUFFQSxlQUFlMUI7QUFBVyxJQUFBbUI7QUFBQVEsYUFBQVIsSUFBQSIsIm5hbWVzIjpbIk1hcCIsIkxheWVyIiwiU291cmNlIiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJhcGlfa2V5IiwiZ2VvTGF5ZXIiLCJvdmVybGF5RGF0YSIsImdldEZldGNoZWREYXRhIiwib3ZlcmxheVNwZWNpYWxEYXRhIiwiV3JhcHBlZE1hcCIsIl9zIiwidmlld1N0YXRlIiwic2V0Vmlld1N0YXRlIiwibG9uZ2l0dWRlIiwibGF0aXR1ZGUiLCJ6b29tIiwib3ZlcmxheSIsInNldE92ZXJsYXkiLCJ1bmRlZmluZWQiLCJmZXRjaERhdGEiLCJyZWd1bGFyT3ZlcmxheSIsInNwZWNpYWxPdmVybGF5IiwiZXYiLCJ3aWR0aCIsIndpbmRvdyIsImlubmVyV2lkdGgiLCJoZWlnaHQiLCJpbm5lckhlaWdodCIsIl9jIiwib25NYXBDbGljayIsImUiLCJjb25zb2xlIiwibG9nIiwibG5nTGF0IiwibGF0IiwibG5nIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiV3JhcHBlZE1hcC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IE1hcCwge1xuICBMYXllcixcbiAgTWFwTGF5ZXJNb3VzZUV2ZW50LFxuICBTb3VyY2UsXG4gIFZpZXdTdGF0ZUNoYW5nZUV2ZW50LFxufSBmcm9tIFwicmVhY3QtbWFwLWdsXCI7XG5pbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgYXBpX2tleSB9IGZyb20gXCIuLi9Qcml2YXRlL1Rva2VuLmpzXCI7XG5pbXBvcnQgeyBnZW9MYXllciwgb3ZlcmxheURhdGEgfSBmcm9tIFwiLi9PdmVybGF5LmpzXCI7XG5pbXBvcnQgeyBnZXRGZXRjaGVkRGF0YSwgb3ZlcmxheVNwZWNpYWxEYXRhIH0gZnJvbSBcIi4uL2NvbW1hbmRzL2FyZWFDb21tYW5kLmpzXCI7XG5cbi8qKlxuICogRnVuY3Rpb25hbCBjb21wb25lbnQgcmVwcmVzZW50aW5nIGEgbWFwIHdpdGggb3ZlcmxheXMuXG4gKi9cbmZ1bmN0aW9uIFdyYXBwZWRNYXAoKSB7XG4gIC8vIEluaXRpYWwgbGF0aXR1ZGUsIGxvbmdpdHVkZSwgYW5kIHpvb20gZm9yIFByb3ZpZGVuY2VcbiAgY29uc3QgW3ZpZXdTdGF0ZSwgc2V0Vmlld1N0YXRlXSA9IHVzZVN0YXRlKHtcbiAgICBsb25naXR1ZGU6IC03MS40MTg4ODQsXG4gICAgbGF0aXR1ZGU6IDQxLjgyNTIyNixcbiAgICB6b29tOiAxMixcbiAgfSk7XG4gIC8vIFN0YXRlIHRvIG1hbmFnZSB0aGUgb3ZlcmxheSBkYXRhXG4gIGNvbnN0IFtvdmVybGF5LCBzZXRPdmVybGF5XSA9IHVzZVN0YXRlPEdlb0pTT04uRmVhdHVyZUNvbGxlY3Rpb24gfCB1bmRlZmluZWQ+KFxuICAgIHVuZGVmaW5lZFxuICApO1xuICBcblxuICAvKipcbiAgICogRWZmZWN0IGhvb2sgdG8gZmV0Y2ggb3ZlcmxheSBkYXRhIGFuZCB1cGRhdGUgdGhlIHN0YXRlLlxuICAgKi9cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBmZXRjaERhdGEgPSBhc3luYyAoKSA9PiB7XG4gICAgICAvLyBHZXQgcmVndWxhciBhbmQgc3BlY2lhbCBvdmVybGF5c1xuICAgICAgY29uc3QgcmVndWxhck92ZXJsYXkgPSBvdmVybGF5RGF0YSgpO1xuICAgICAgY29uc3Qgc3BlY2lhbE92ZXJsYXkgPSBhd2FpdCBvdmVybGF5U3BlY2lhbERhdGEoKTtcblxuXG4gICAgICAvLyBVc2UgdGhlIHNwZWNpYWwgb3ZlcmxheSBpZiB0aGVyZSBpcyBmZXRjaGVkIGRhdGEsIG90aGVyd2lzZSB1c2UgdGhlIHJlZ3VsYXIgb3ZlcmxheVxuICAgICAgc2V0T3ZlcmxheShnZXRGZXRjaGVkRGF0YSgpID8gc3BlY2lhbE92ZXJsYXkgOiByZWd1bGFyT3ZlcmxheSk7XG4gICAgfTtcbiAgICBmZXRjaERhdGEoKTtcbiAgfSwgW2dldEZldGNoZWREYXRhKCksIG92ZXJsYXlTcGVjaWFsRGF0YSgpLCBvdmVybGF5RGF0YSgpXSk7XG5cbiAgLyoqXG4gICAqIFJlbmRlciB0aGUgbWFwIGNvbXBvbmVudCB3aXRoIG92ZXJsYXlzLlxuICAgKi9cbiAgcmV0dXJuIChcbiAgICA8TWFwXG4gICAgICBsb25naXR1ZGU9e3ZpZXdTdGF0ZS5sb25naXR1ZGV9XG4gICAgICBsYXRpdHVkZT17dmlld1N0YXRlLmxhdGl0dWRlfVxuICAgICAgem9vbT17dmlld1N0YXRlLnpvb219XG4gICAgICBtYXBib3hBY2Nlc3NUb2tlbj17YXBpX2tleX1cbiAgICAgIG9uTW92ZT17KGV2OiBWaWV3U3RhdGVDaGFuZ2VFdmVudCkgPT4gc2V0Vmlld1N0YXRlKGV2LnZpZXdTdGF0ZSl9XG4gICAgICBzdHlsZT17eyB3aWR0aDogd2luZG93LmlubmVyV2lkdGgsIGhlaWdodDogd2luZG93LmlubmVySGVpZ2h0IH19XG4gICAgICBtYXBTdHlsZT17XCJtYXBib3g6Ly9zdHlsZXMvbWFwYm94L3N0cmVldHMtdjEyXCJ9XG4gICAgPlxuICAgICAgey8qIEFkZCBhIHNvdXJjZSBhbmQgbGF5ZXIgZm9yIHRoZSBvdmVybGF5IGRhdGEgKi99XG4gICAgICA8U291cmNlIGlkPVwiZ2VvX2RhdGFcIiB0eXBlPVwiZ2VvanNvblwiIGRhdGE9e292ZXJsYXl9PlxuICAgICAgICA8TGF5ZXIgey4uLmdlb0xheWVyfSAvPlxuICAgICAgPC9Tb3VyY2U+XG4gICAgPC9NYXA+XG4gICk7XG59XG5cbi8qKlxuICogSGFuZGxlciBmdW5jdGlvbiBmb3IgbWFwIGNsaWNrIGV2ZW50cy5cbiAqIEBwYXJhbSB7TWFwTGF5ZXJNb3VzZUV2ZW50fSBlIC0gVGhlIG1hcCBjbGljayBldmVudC5cbiAqL1xuZnVuY3Rpb24gb25NYXBDbGljayhlOiBNYXBMYXllck1vdXNlRXZlbnQpIHtcbiAgY29uc29sZS5sb2coZSk7XG4gIGNvbnNvbGUubG9nKGUubG5nTGF0LmxhdCk7XG4gIGNvbnNvbGUubG9nKGUubG5nTGF0LmxuZyk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IFdyYXBwZWRNYXA7Il0sImZpbGUiOiIvVXNlcnMvamFrZXN0aWZlbG1hbi9DUzMyTG9jYWwvbWFwcy1qc3RpZmVsMS14anF1YW4vZnJvbnRlbmQvc3JjL01hcC9XcmFwcGVkTWFwLnRzeCJ9